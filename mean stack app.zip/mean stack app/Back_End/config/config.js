var dotenv = require('dotenv');

dotenv.config();

module.exports = config;