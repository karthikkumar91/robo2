const express = require('express');
const app = express();
const path = require('path'),
mongoose = require('mongoose'),
cors = require('cors'),
bodyParser = require('body-parser'),
dbConfig = require('./database/db');

const userInViews = require('./routes/userInViews');
const indexRouter = require('./routes/index');

// Connecting with mongo db
mongoose.Promise = global.Promise;
mongoose.connect(dbConfig.db, {
    useNewUrlParser: true
    }).then(() => {
    console.log('Database sucessfully connected')
},
error => {
    console.log('Database could not connected: ' + error)
})


// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
app.use(express.static(path.join(__dirname, 'public')));


app.use(userInViews());
app.use('/', indexRouter);



module.exports = app;