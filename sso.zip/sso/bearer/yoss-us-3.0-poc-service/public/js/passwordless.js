
var webAuth = new auth0.WebAuth({
    clientID: 'hQIJr5XDYsrj0AjC6kLucZ1L0UoDPprB', 
    domain: 'dev-yoss.auth0.com',
    redirectUri: 'http://localhost:3000/callback',
    responseType: 'code',
    scope: 'openid profile'
  });
function get(){
   
   // var email = $('input.email').val();
    var email=document.getElementsByTagName('input')[0].value
    console.log(email);

      webAuth.passwordlessStart({
        connection: 'email',
        send: 'link',
        email: email
      }, function(err) {
        if (err) {
          alert('error sending email: '+ err.error_description);
          return;
        }
        // the request was successful and you should 
        // receive the magic link in the specified email
        alert('email sent successfully!');
      });
}
// function aj_get(){
//     var email=document.getElementsByTagName('input')[0].value
//     console.log(email);
//     var url = "sample/?sm="+email;
//     var xhttp = new XMLHttpRequest();
//     xhttp.onreadystatechange = function() {
//         if (this.readyState == 4 && this.status == 200) {
//             alert('email sent!');
//            }
//     }
//     xhttp.open("POST",url, true);
//   xhttp.send();
// }