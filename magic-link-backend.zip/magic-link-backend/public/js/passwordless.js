function magic_link(){

    var email=document.getElementsByTagName('input')[0].value
    //console.log(email);
    //creating object for ajax call
    var xhttp = new XMLHttpRequest();

    //adding url and data as keyvalue format to ajax call
    let url = "/magic/link"
    var data = {};
    data.email=email;

    //converting json into string using stringify method
    var json = JSON.stringify(data);
    
    //opening connection for post request and adding the type for sending msg
    xhttp.open("POST",url, true);
    xhttp.setRequestHeader('Content-type','application/json; charset=utf-8');
    
    //checking  status for ajax call
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert('email sent!');
           }
    }
    //sending the ajax values as json format
  xhttp.send(json);
}