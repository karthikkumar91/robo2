# Introduction 
This repo will be used to host all Yoss 3.0 backend POCs.
Beyond POC, each feature/service potentially may be be hosted in its own repo.

# Code Organization
1. Each POC Feature/PBI is hosted in a separate branch as follows:
e.g.: 
* #17929 : `feature/17929-twilio-1-to-1-msg`
* #17936 : `feature/17936-auth0-user-mgt`

2. Merge branches:
For 
* Twilio features: `develop-twilio`
* Auth0 features: `develop-auth0`