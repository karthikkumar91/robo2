const express = require('express');
const router = express.Router();
const passport = require('passport');
// var dotenv = require('dotenv');
const util = require('util');
//const url = require('url');
const body = require('body-parser');
const querystring = require('querystring');
const config =require('../config/config').auth0;
const AuthenticationClient = require('auth0').AuthenticationClient;

// Share the link via email
router.get('/email/:mode', (req, res) => {
  res.render('email-'+req.params.mode);
});

// Share the login, after login Auth0 will redirect to callback
router.get('/login', passport.authenticate('auth0', {
  scope: 'openid email profile'
}), function (req, res) {
  res.redirect('/');
});

router.post('/magic/link',function(req,res){
//console.log("URL:--->"+req.url)
var email = req.body.email;
console.log('value reveiew:--->',email)
  let auth0 = new AuthenticationClient({
    domain : config.domain,
    clientId : config.clientID,
    clientSecret : config.clientSecret,
  })
  let data = {
    connection: 'email',
    send : 'link',
    email : email,
  }
  auth0.passwordless.sendEmail(data,function(err){
    if(err){
      console.log(err);
    }
    else{
      console.log("email-send successfully")
      res.end('sucess');
    }
  })
})

// Perform the final stage of authentication and redirect to previously requested URL or '/user'
router.get('/callback', function (req, res, next) {
  passport.authenticate('auth0', function (err, user, info) {
    if (err) { return next(err); }
    if (!user) { return res.redirect('/login'); }
    req.logIn(user, function (err) {
      if (err) { return next(err); }
      const returnTo = req.session.returnTo;
      console.log("data:--->"+returnTo)
      delete req.session.returnTo;
      res.redirect(returnTo || '/user');
    });
  })(req, res, next);
});

//Perform session logout and redirect to homepage
router.get('/logout', (req, res) => {
  req.logout();
  
  let returnTo = req.protocol + '://' + req.hostname;
  let port = req.connection.localPort;
  if (port !== undefined && port !== 80 && port !== 443) {
    returnTo += ':' + port;
  }
  console.log("checking:--->"+returnTo)
  let logoutURL = new URL(
    util.format('https://%s/logout', config.domain)
  );
  let searchString = querystring.stringify({
    client_id: config.clientID,
    returnTo: returnTo
  });
  logoutURL.search = searchString;

  res.redirect(logoutURL);
});



module.exports = router;
